#pragma once

class SerialAudioIO
{
	public:
		virtual void updateIO() {};
};